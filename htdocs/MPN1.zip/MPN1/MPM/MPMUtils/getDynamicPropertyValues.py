


def getDynamicPropertyValues(data):
    """
    This method is used to send dynamic values based on property_name variable
    Need to implement for Dic and object
    :param data:
    :return:
    """
    #print(data.get('Tagdata').get(data.get('property_name')))
    return data.get('Tagdata').get(data.get('property_name'))