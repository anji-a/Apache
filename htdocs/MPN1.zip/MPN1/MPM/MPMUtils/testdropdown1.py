

def testdropdown1(data):
    return {'choices': {'c': {'key':'k','value':'v'},'f':{'key':'k1','value':'v1'}}}