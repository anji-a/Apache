from django.apps import AppConfig


class MmConfig(AppConfig):
    name = 'MM'
